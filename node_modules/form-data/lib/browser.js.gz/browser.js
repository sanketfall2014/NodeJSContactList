/* eslint-env browser */
module.exports = FormData;
