parse-mongo-url
===============

Parse mongodb connection strings. This is based on the 
[connection string parser](https://github.com/mongodb/node-mongodb-native/blob/2.0/lib/url_parser.js) 
from the [mongodb driver](https://github.com/mongodb/node-mongodb-native).

License
-------

Apache 2.0
